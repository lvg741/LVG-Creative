import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "LVG Creative | Video Production, Editing & Social Media Content",
  description: "LVG Creative offers video production, video editing and social media content for businesses and creators.",
  metadataBase: new URL("https://www.lvgcreative.co.uk"),
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-GB">
      <body>{children}</body>
    </html>
  );
}
