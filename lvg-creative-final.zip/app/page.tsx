import Image from "next/image";
import { ArrowRight, BarChart3, Camera, Clapperboard, Instagram, Mail, Play, Users } from "lucide-react";

const services = [
  { icon: Camera, title: "Video Production", text: "Promotional videos, brand storytelling and campaign visuals for modern businesses." },
  { icon: Clapperboard, title: "Video Editing", text: "Polished editing for reels, ads, YouTube content, interviews, podcasts and campaigns." },
  { icon: Instagram, title: "Social Media Content", text: "Scroll-stopping content for Instagram, TikTok, LinkedIn, Facebook and YouTube Shorts." },
];

const portfolio = ["Brand Launch Video", "Social Reels Campaign", "Podcast Edit Package", "Product Promo Video"];
const stats = [["120+", "videos and edits delivered"], ["42%", "average reach increase"], ["3.8x", "average engagement lift"]];

export default function Home() {
  return (
    <main className="min-h-screen bg-slate-950 text-white">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-4 text-xl font-bold">
          <Image src="/logo.jpeg" alt="LVG Creative logo" width={72} height={72} className="h-14 w-auto rounded-xl bg-white p-1" priority />
          <span>LVG Creative</span>
        </div>
        <div className="hidden gap-8 text-sm text-slate-300 md:flex">
          <a href="#services" className="hover:text-white">Services</a>
          <a href="#portfolio" className="hover:text-white">Portfolio</a>
          <a href="#contact" className="hover:text-white">Contact</a>
        </div>
        <a href="mailto:leah@lvgcreative.co.uk" className="rounded-full bg-white px-5 py-3 text-sm font-semibold text-slate-950 hover:bg-slate-200">Book a call</a>
      </nav>

      <section className="mx-auto grid max-w-7xl items-center gap-12 px-6 py-20 lg:grid-cols-2 lg:py-28">
        <div>
          <div className="mb-6 inline-flex rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-300">Creative digital marketing for ambitious brands</div>
          <h1 className="text-5xl font-bold tracking-tight md:text-7xl">Video content that helps your brand get noticed.</h1>
          <p className="mt-6 max-w-xl text-lg leading-8 text-slate-300">LVG Creative helps businesses grow through powerful video production, professional editing and social media content that builds attention and drives engagement.</p>
          <div className="mt-8 flex flex-col gap-4 sm:flex-row">
            <a href="#contact" className="inline-flex items-center justify-center rounded-full bg-purple-600 px-6 py-4 font-semibold text-white hover:bg-purple-500">Start your enquiry <ArrowRight className="ml-2 h-4 w-4" /></a>
            <a href="#portfolio" className="inline-flex items-center justify-center rounded-full border border-white/20 px-6 py-4 font-semibold text-white hover:bg-white/10">View portfolio</a>
          </div>
        </div>
        <div className="rounded-[2rem] border border-white/10 bg-white/5 p-4 shadow-2xl">
          <div className="rounded-[1.5rem] bg-slate-900 p-8">
            <Play className="mb-6 h-12 w-12 text-purple-300" />
            <h2 className="text-3xl font-bold">Showreel Placeholder</h2>
            <p className="mt-4 text-slate-300">Add your main showreel, launch video or best social campaign here.</p>
            <div className="mt-8 aspect-video rounded-2xl border border-dashed border-white/20 bg-slate-950" />
          </div>
        </div>
      </section>

      <section id="services" className="mx-auto max-w-7xl px-6 py-20">
        <p className="text-sm font-semibold uppercase tracking-widest text-purple-300">Services</p>
        <h2 className="mt-3 text-4xl font-bold">Everything you need to create better content.</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {services.map((service) => {
            const Icon = service.icon;
            return <div key={service.title} className="rounded-3xl border border-white/10 bg-white/5 p-8 shadow-xl"><div className="mb-6 flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-600"><Icon className="h-6 w-6" /></div><h3 className="text-xl font-semibold">{service.title}</h3><p className="mt-3 leading-7 text-slate-300">{service.text}</p></div>;
          })}
        </div>
      </section>

      <section className="border-y border-white/10 bg-white/5 py-16">
        <div className="mx-auto grid max-w-7xl gap-6 px-6 md:grid-cols-3">
          {stats.map(([number, label]) => <div key={label} className="rounded-3xl bg-slate-950 p-8 text-center"><div className="text-5xl font-bold text-purple-300">{number}</div><p className="mt-3 text-slate-300">{label}</p></div>)}
        </div>
      </section>

      <section id="portfolio" className="mx-auto max-w-7xl px-6 py-20">
        <p className="text-sm font-semibold uppercase tracking-widest text-purple-300">Portfolio</p>
        <h2 className="mt-3 text-4xl font-bold">Showreels, reels, edits and content campaigns.</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {portfolio.map((item) => <div key={item} className="rounded-3xl border border-white/10 bg-white/5 p-5"><div className="mb-5 flex aspect-video items-center justify-center rounded-2xl bg-slate-900 text-slate-400">Video Placeholder</div><h3 className="font-semibold">{item}</h3><p className="mt-2 text-sm text-slate-300">Replace with an embedded video or case study.</p></div>)}
        </div>
      </section>

      <section id="contact" className="mx-auto max-w-5xl px-6 py-24">
        <div className="rounded-[2rem] bg-purple-600 p-10 text-center md:p-16">
          <Mail className="mx-auto mb-5 h-10 w-10" />
          <h2 className="text-4xl font-bold">Ready to create better content?</h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-purple-100">Contact LVG Creative for video production, editing and social media content.</p>
          <a href="mailto:leah@lvgcreative.co.uk" className="mt-8 inline-flex items-center justify-center rounded-full bg-slate-950 px-6 py-4 font-semibold text-white hover:bg-slate-800">Email leah@lvgcreative.co.uk <ArrowRight className="ml-2 h-4 w-4" /></a>
          <p className="mt-6 font-medium">www.lvgcreative.co.uk</p>
        </div>
      </section>
    </main>
  );
}
